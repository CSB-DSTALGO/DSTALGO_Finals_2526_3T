using System;

namespace DataStructuresLibrary
{
    // Custom array-based Queue (FIFO: First In, First Out).
    // Built manually without System.Collections.Generic, as required.
    // Uses a circular buffer so Enqueue/Dequeue stay O(1) without shifting elements.
    public class CustomQueue<T>
    {
        private T[] _items;   // backing array
        private int _front;   // index of the current front item
        private int _rear;    // index of the next free slot to enqueue into
        private int _count;   // number of items currently stored
        private const int DefaultCapacity = 4;

        // Number of items currently in the queue.
        public int Count
        {
            get { return _count; }
        }

        public CustomQueue()
        {
            _items = new T[DefaultCapacity];
            _front = 0;
            _rear = 0;
            _count = 0;
        }

        // Adds an item to the back of the queue. Resizes if the array is full.
        public void Enqueue(T item)
        {
            if (_count == _items.Length)
            {
                Resize();
            }

            _items[_rear] = item;
            _rear = (_rear + 1) % _items.Length; // wrap around
            _count++;
        }

        // Removes and returns the front item. Throws if the queue is empty.
        public T Dequeue()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("Cannot Dequeue: the queue is empty.");
            }

            T item = _items[_front];
            _items[_front] = default!;
            _front = (_front + 1) % _items.Length; // wrap around
            _count--;
            return item;
        }

        // Returns the front item without removing it. Throws if the queue is empty.
        public T Peek()
        {
            if (IsEmpty())
            {
                throw new InvalidOperationException("Cannot Peek: the queue is empty.");
            }

            return _items[_front];
        }

        // Returns true if the queue has no items.
        public bool IsEmpty()
        {
            return _count == 0;
        }

        // Returns a copy of all items, ordered front to back.
        // Used for display/searching without disturbing the real queue.
        public T[] ToArray()
        {
            T[] snapshot = new T[_count];
            for (int i = 0; i < _count; i++)
            {
                snapshot[i] = _items[(_front + i) % _items.Length];
            }
            return snapshot;
        }

        // Doubles the array's capacity when full, re-laying items out
        // starting at index 0 so front/rear no longer need to wrap.
        private void Resize()
        {
            int newCapacity = _items.Length * 2;
            T[] newArray = new T[newCapacity];
            for (int i = 0; i < _count; i++)
            {
                newArray[i] = _items[(_front + i) % _items.Length];
            }
            _items = newArray;
            _front = 0;
            _rear = _count;
        }
    }
}
